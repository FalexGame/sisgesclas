package uts.edu.java.proyecto.servicio;

import java.util.List;
import uts.edu.java.proyecto.modelo.Estudiante;

public interface EstudianteServicio {
    List<Estudiante> listar();
    Estudiante obtenerPorCodigo(String codigo);
    Estudiante buscarPorDocumento(String documento);
    void guardar(Estudiante estudiante);
    void eliminar(String codigo);
}
