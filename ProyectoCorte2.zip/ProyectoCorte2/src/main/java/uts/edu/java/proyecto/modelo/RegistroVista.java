package uts.edu.java.proyecto.modelo;

import java.time.LocalDate;

public class RegistroVista {

    private Long idRegistro;
    private String codigoEstudiante;
    private String nombreEstudiante;
    private String apellidoEstudiante;
    private LocalDate fechaClase;
    private String estado;
    private String materiaTema;
    private String nombreDocente;
    private String apellidoDocente;
    private String grado;


    public RegistroVista(
            Long idRegistro,
            String codigoEstudiante,
            String nombreEstudiante,
            String apellidoEstudiante,
            LocalDate fechaClase,
            String estado,
            String materiaTema,
            String nombreDocente,
            String apellidoDocente,
            String grado) {

        this.idRegistro = idRegistro;
        this.codigoEstudiante = codigoEstudiante;
        this.nombreEstudiante = nombreEstudiante;
        this.apellidoEstudiante = apellidoEstudiante;
        this.fechaClase = fechaClase;
        this.estado = estado;
        this.materiaTema = materiaTema;
        this.nombreDocente = nombreDocente;
        this.apellidoDocente = apellidoDocente;
        this.grado = grado;
    }

   
    public Long getIdRegistro() { return idRegistro; }
    public String getCodigoEstudiante() { return codigoEstudiante; }
    public String getNombreEstudiante() { return nombreEstudiante; }
    public String getApellidoEstudiante() { return apellidoEstudiante; }
    public LocalDate getFechaClase() { return fechaClase; }
    public String getEstado() { return estado; }
    public String getMateriaTema() { return materiaTema; }
    public String getNombreDocente() { return nombreDocente; }
    public String getApellidoDocente() { return apellidoDocente; }
    public String getGrado() {
        return grado;
    }
    
}
