package uts.edu.java.proyecto.servicio;

import java.util.List;
import uts.edu.java.proyecto.modelo.Docente;

public interface DocenteServicio {
    List<Docente> listar();
    Docente obtenerPorId(Integer id);
    void guardar(Docente docente);
    void eliminar(Integer id);
}
