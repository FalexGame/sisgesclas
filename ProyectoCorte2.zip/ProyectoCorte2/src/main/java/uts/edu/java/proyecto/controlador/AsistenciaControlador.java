package uts.edu.java.proyecto.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import uts.edu.java.proyecto.modelo.Estudiante;
import uts.edu.java.proyecto.modelo.RegistroAsistencia;
import uts.edu.java.proyecto.servicio.CustomUserDetails;
import uts.edu.java.proyecto.servicio.DocenteServicio;
import uts.edu.java.proyecto.servicio.EstudianteServicio;
import uts.edu.java.proyecto.servicio.RegistroAsistenciaServicio;

@Controller
@RequestMapping("/asistencia")
public class AsistenciaControlador {

    @Autowired
    private RegistroAsistenciaServicio servicio;

    @Autowired
    private DocenteServicio docenteServicio;

    @Autowired
    private EstudianteServicio estudianteServicio;

 
    // LISTADO GENERAL — SOLO ADMIN / DOCENTE (no estudiante)

    @GetMapping
    public String listar(Model model, Authentication auth) {

        // Si ES estudiante → NO permitir ver lista general
        if (auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ESTUDIANTE"))) {
            return "redirect:/asistencia/mis";
        }

        model.addAttribute("registros", servicio.listarConJoin());
        return "views/asistencia/list";
    }


    // FORMULARIO NUEVO REGISTRO
 
    @GetMapping("/nuevo")
    public String nuevo(Model model, Authentication auth) {

        // Estudiante NO puede registrar asistencias
        if (auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ESTUDIANTE"))) {
            return "redirect:/asistencia/mis";
        }

        model.addAttribute("registro", new RegistroAsistencia());
        model.addAttribute("docentes", docenteServicio.listar());
        model.addAttribute("estudiantes", estudianteServicio.listar());
        return "views/asistencia/form";
    }


    // GUARDAR REGISTRO

    @PostMapping
    public String guardar(@ModelAttribute("registro") RegistroAsistencia registro,
                          RedirectAttributes redirectAttrs) {

        try {
            Estudiante estudiante = estudianteServicio.obtenerPorCodigo(registro.getCodigoEstudiante());
            registro.setGrado(estudiante.getGrado());  // ← COPIA AUTOMÁTICA DEL GRADO

            servicio.guardar(registro);
            redirectAttrs.addFlashAttribute("msgSuccess", "Asistencia registrada correctamente");

        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("msgError", "Error al guardar asistencia");
        }

        return "redirect:/asistencia";
    }


    // EDITAR
 
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, Authentication auth) {

        if (auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ESTUDIANTE"))) {
            return "redirect:/asistencia/mis";
        }

        model.addAttribute("registro", servicio.buscarPorId(id));
        model.addAttribute("docentes", docenteServicio.listar());
        model.addAttribute("estudiantes", estudianteServicio.listar());
        return "views/asistencia/form";
    }


    // ELIMINAR
   
    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id,
                           RedirectAttributes redirectAttrs,
                           Authentication auth) {

        if (auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ESTUDIANTE"))) {
            return "redirect:/asistencia/mis";
        }

        try {
            servicio.eliminar(id);
            redirectAttrs.addFlashAttribute("msgSuccess", "Registro eliminado correctamente");
        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("msgError", "No se puede eliminar: " + e.getMessage());
        }
        return "redirect:/asistencia";
    }

  
    // ASISTENCIAS (ESTUDIANTE AUTENTICADO)
   
    @GetMapping("/mis")
    public String misAsistencias(Model model, Authentication auth) {

        CustomUserDetails userDetails = (CustomUserDetails) auth.getPrincipal();

        
        // Obtiene E001, E002, E003 desde la tabla users
        String codigoEstudiante = userDetails.getReferenciaEstudiante();

        var estudiante = estudianteServicio.obtenerPorCodigo(codigoEstudiante);

        if (estudiante == null) {
            model.addAttribute("msgError", "No se encontró el estudiante asociado al usuario.");
            model.addAttribute("misRegistros", null);
            return "views/asistencia/mis";
        }

        model.addAttribute("estudiante", estudiante);

        // se listan las asistencias 
        var registros = servicio.listarPorCodigoEstudiante(estudiante.getCodigo());
        model.addAttribute("misRegistros", registros);

        return "views/asistencia/mis";
    }


}
