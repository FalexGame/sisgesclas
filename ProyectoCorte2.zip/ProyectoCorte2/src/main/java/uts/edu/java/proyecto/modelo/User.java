package uts.edu.java.proyecto.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_user")
    private Integer idUser;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @ManyToOne
    @JoinColumn(name = "id_rol")
    private Role rol;

    @Column(name = "referencia_docente")
    private Integer referenciaDocente;

    @Column(name = "referencia_estudiante", length = 20)
    private String referenciaEstudiante;

    @Column(name = "nombre_display", length = 150)
    private String nombreDisplay;

    @Column(nullable = false)
    private boolean activo = true;

   

    public Integer getIdUser() {
        return idUser;
    }

    public void setIdUser(Integer idUser) {
        this.idUser = idUser;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public Role getRol() {
        return rol;
    }

    public void setRol(Role rol) {
        this.rol = rol;
    }

    public Integer getReferenciaDocente() {
        return referenciaDocente;
    }

    public void setReferenciaDocente(Integer referenciaDocente) {
        this.referenciaDocente = referenciaDocente;
    }

    public String getReferenciaEstudiante() {
        return referenciaEstudiante;
    }

    public void setReferenciaEstudiante(String referenciaEstudiante) {
        this.referenciaEstudiante = referenciaEstudiante;
    }

    public String getNombreDisplay() {
        return nombreDisplay;
    }

    public void setNombreDisplay(String nombreDisplay) {
        this.nombreDisplay = nombreDisplay;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}
