package uts.edu.java.proyecto.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import uts.edu.java.proyecto.repositorio.DocenteRepositorio;
import uts.edu.java.proyecto.repositorio.EstudianteRepositorio;
import uts.edu.java.proyecto.repositorio.RegistroAsistenciaRepositorio;

import org.springframework.ui.Model;

@Controller
public class AppController {

    @Autowired
    private EstudianteRepositorio estudianteRepo;

    @Autowired
    private DocenteRepositorio docenteRepo;

    @Autowired
    private RegistroAsistenciaRepositorio asistenciaRepo;

    // Página principal
    @GetMapping({"/", "/home"})
    public String index(Model model) {

        long totalEstudiantes = estudianteRepo.count();
        long totalDocentes = docenteRepo.count();
        long totalAsistencias = asistenciaRepo.count();

        model.addAttribute("totalEstudiantes", totalEstudiantes);
        model.addAttribute("totalDocentes", totalDocentes);
        model.addAttribute("totalAsistencias", totalAsistencias);

        return "home";
    }

    // Redireccion
    @GetMapping("/docentes")
    public String redirectDocentes() {
        return "redirect:/docente";
    }

}
