package uts.edu.java.proyecto.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import uts.edu.java.proyecto.modelo.Estudiante;
import uts.edu.java.proyecto.servicio.EstudianteServicio;

@Controller
@RequestMapping("/estudiante")
public class EstudianteControlador {

    @Autowired
    private EstudianteServicio servicio;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("estudiantes", servicio.listar());
        model.addAttribute("estudiante", new Estudiante()); 
        return "views/estudiante/Elist";
    }


    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("estudiante", new Estudiante());
        return "views/estudiante/Eform";
    }

    @PostMapping
    public String guardar(@ModelAttribute("estudiante") Estudiante estudiante,
                          RedirectAttributes redirectAttrs) {
        try {
            boolean esNuevo = servicio.obtenerPorCodigo(estudiante.getCodigo()) == null;
            servicio.guardar(estudiante);
            if (esNuevo) {
                redirectAttrs.addFlashAttribute("msgSuccess", "Estudiante registrado correctamente");
            } else {
                redirectAttrs.addFlashAttribute("msgSuccess", "Estudiante editado correctamente");
            }
        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("msgError", "Error al guardar estudiante: " + e.getMessage());
        }
        return "redirect:/estudiante";
    }



    @GetMapping("/editar/{codigo}")
    public String editar(@PathVariable String codigo, Model model) {
        model.addAttribute("estudiante", servicio.obtenerPorCodigo(codigo));
        return "views/estudiante/Eform";
    }

    @GetMapping("/eliminar/{codigo}")
    public String eliminar(@PathVariable String codigo, RedirectAttributes redirectAttrs) {
        try {
            servicio.eliminar(codigo);
            redirectAttrs.addFlashAttribute("msgSuccess", "Estudiante eliminado correctamente");
        } catch (DataIntegrityViolationException e) {
            redirectAttrs.addFlashAttribute("msgError", 
                "No se puede eliminar este estudiante: tiene registros de asistencia");
        }
        return "redirect:/estudiante";
    }

}
