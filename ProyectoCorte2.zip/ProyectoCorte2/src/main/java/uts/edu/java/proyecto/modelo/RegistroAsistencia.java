package uts.edu.java.proyecto.modelo;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "tb_registro_asistencia")
public class RegistroAsistencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_registro")
    private Long idRegistro;

    @Column(name = "codigo_estudiante", length = 20, nullable = false)
    private String codigoEstudiante;

    @Column(name = "id_docente", nullable = false)
    private Integer idDocente;

    @Column(name = "fecha_clase", nullable = false)
    private LocalDate fechaClase;

  
    @Column(name = "estado", length = 1, nullable = false)
    private String estado;

    @Column(name = "materia_tema", length = 100)
    private String materiaTema;
    
    @Column(length = 5)
    private String grado;

   

    public Long getIdRegistro() {
        return idRegistro;
    }

    public void setIdRegistro(Long idRegistro) {
        this.idRegistro = idRegistro;
    }

    public String getCodigoEstudiante() {
        return codigoEstudiante;
    }

    public void setCodigoEstudiante(String codigoEstudiante) {
        this.codigoEstudiante = codigoEstudiante;
    }

    public Integer getIdDocente() {
        return idDocente;
    }

    public void setIdDocente(Integer idDocente) {
        this.idDocente = idDocente;
    }

    public LocalDate getFechaClase() {
        return fechaClase;
    }

    public void setFechaClase(LocalDate fechaClase) {
        this.fechaClase = fechaClase;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMateriaTema() {
        return materiaTema;
    }

    public void setMateriaTema(String materiaTema) {
        this.materiaTema = materiaTema;
    }
    
    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }
}
