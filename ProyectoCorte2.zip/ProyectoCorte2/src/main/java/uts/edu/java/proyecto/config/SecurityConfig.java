package uts.edu.java.proyecto.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import uts.edu.java.proyecto.servicio.CustomUserDetailsService;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;
    private final AuthenticationSuccessHandler successHandler;

    public SecurityConfig(CustomUserDetailsService userDetailsService,
                          AuthenticationSuccessHandler successHandler) {
        this.userDetailsService = userDetailsService;
        this.successHandler = successHandler;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
          .csrf(csrf -> csrf.disable())
          .authorizeHttpRequests(auth -> auth
        		  .requestMatchers("/login", "/css/**", "/js/**", "/images/**").permitAll()

        		// Solo superadmin ve docentes
        		.requestMatchers("/docente/**").hasRole("SUPERADMIN")

        		// Estudiante no puede ver estudiantes
        		.requestMatchers("/estudiante/**").hasAnyRole("SUPERADMIN","DOCENTE")

        		// solo estudiante puede ver sus asistencias
        		.requestMatchers("/asistencia/mis").hasRole("ESTUDIANTE")

        		// Rutas de asistencia para todos los roles
        		.requestMatchers("/asistencia/**").hasAnyRole("SUPERADMIN","DOCENTE","ESTUDIANTE")

        		// Home listo a todo usuario autenticado
        		.requestMatchers("/home").authenticated()

        		
        		.requestMatchers("/").permitAll()

        		.anyRequest().authenticated()
          )
          .formLogin(form -> form
              .loginPage("/login")
              .successHandler(successHandler)
              .permitAll()
          )
          .logout(logout -> logout
              .logoutUrl("/logout")
              .logoutSuccessUrl("/login?logout")
              .permitAll()
          );

        return http.build();
    }

    @Bean
    public DaoAuthenticationProvider authProvider(PasswordEncoder encoder) {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(encoder);
        return authProvider;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
