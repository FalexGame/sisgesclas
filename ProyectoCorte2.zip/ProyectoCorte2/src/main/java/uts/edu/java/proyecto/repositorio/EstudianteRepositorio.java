package uts.edu.java.proyecto.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uts.edu.java.proyecto.modelo.Estudiante;

@Repository
public interface EstudianteRepositorio extends JpaRepository<Estudiante, String> {

    // Busca estudiante por el campo
    Estudiante findByDocumento(String documento);
    Estudiante findByCodigo(String codigo);

}
