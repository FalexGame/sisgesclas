package uts.edu.java.proyecto.servicio;

import java.util.List;
import uts.edu.java.proyecto.modelo.RegistroAsistencia;
import uts.edu.java.proyecto.modelo.RegistroVista;

public interface RegistroAsistenciaServicio {

    List<RegistroAsistencia> listar();
    RegistroAsistencia obtenerPorId(Long id);
    void guardar(RegistroAsistencia registro) throws Exception;
    void eliminar(Long id);

    List<RegistroVista> listarConJoin();

    // Para mostrar asistencias del estudiante logueado
    RegistroAsistencia buscarPorId(Long id);

    
    List<RegistroAsistencia> listarPorCodigoEstudiante(String codigo);
 

}
