package uts.edu.java.proyecto.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import uts.edu.java.proyecto.modelo.Docente;
import uts.edu.java.proyecto.servicio.DocenteServicio;

@Controller
@RequestMapping("/docente")
public class DocenteControlador {

    @Autowired
    private DocenteServicio servicio;

    @GetMapping
    public String listarDocentes(Model model) {
        model.addAttribute("docentes", servicio.listar());
        return "views/docente/list";

    }

    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("docente", new Docente());
        return "views/docente/form";
    }

    @PostMapping
    public String guardarDocente(@ModelAttribute("docente") Docente docente,
                                 RedirectAttributes redirectAttrs) {
        boolean esNuevo = docente.getIdDocente() == null;
        servicio.guardar(docente);

        if (esNuevo) {
            redirectAttrs.addFlashAttribute("msgSuccess", "Docente registrado correctamente");
        } else {
            redirectAttrs.addFlashAttribute("msgSuccess", "Docente editado correctamente");
        }

        return "redirect:/docente";
    }


    @GetMapping("/editar/{id}")
    public String editarDocente(@PathVariable Integer id, Model model) {
        Docente docente = servicio.obtenerPorId(id);
        model.addAttribute("docente", docente);
        return "views/docente/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarDocente(@PathVariable Integer id, RedirectAttributes redirectAttrs) {
        try {
            servicio.eliminar(id);
            redirectAttrs.addFlashAttribute("msgSuccess", "Docente eliminado correctamente");
        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("msgError", "No se puede eliminar este docente: " + e.getMessage());
        }
        return "redirect:/docente";
    }

}
