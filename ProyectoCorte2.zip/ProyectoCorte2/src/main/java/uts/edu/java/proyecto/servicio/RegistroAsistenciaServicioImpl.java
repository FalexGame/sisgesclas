package uts.edu.java.proyecto.servicio;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uts.edu.java.proyecto.modelo.RegistroAsistencia;
import uts.edu.java.proyecto.modelo.RegistroVista;
import uts.edu.java.proyecto.repositorio.RegistroAsistenciaRepositorio;

@Service
public class RegistroAsistenciaServicioImpl implements RegistroAsistenciaServicio {

    @Autowired
    private RegistroAsistenciaRepositorio repositorio;

    @Override
    public List<RegistroAsistencia> listar() {
        return repositorio.findAll();
    }

    @Override
    public RegistroAsistencia obtenerPorId(Long id) {
        return repositorio.findById(id).orElse(null);
    }

    @Override
    public void guardar(RegistroAsistencia registro) throws Exception {
        repositorio.save(registro);
    }

    @Override
    public void eliminar(Long id) {
        repositorio.deleteById(id);
    }

    @Override
    public List<RegistroVista> listarConJoin() {
        return repositorio.listarConJoin();
    }

    @Override
    public RegistroAsistencia buscarPorId(Long id) {
        return repositorio.findById(id).orElse(null);
    }

    
    @Override
    public List<RegistroAsistencia> listarPorCodigoEstudiante(String codigo) {
        return repositorio.listarPorCodigoEstudiante(codigo);
    }
    

}
