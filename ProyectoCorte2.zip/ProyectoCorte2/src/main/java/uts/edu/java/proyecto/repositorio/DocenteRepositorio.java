package uts.edu.java.proyecto.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uts.edu.java.proyecto.modelo.Docente;

@Repository
public interface DocenteRepositorio extends JpaRepository<Docente, Integer> {
}
