package uts.edu.java.proyecto.repositorio;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import uts.edu.java.proyecto.modelo.RegistroAsistencia;
import uts.edu.java.proyecto.modelo.RegistroVista;

@Repository
public interface RegistroAsistenciaRepositorio extends JpaRepository<RegistroAsistencia, Long> {

	@Query("SELECT new uts.edu.java.proyecto.modelo.RegistroVista( "
		     + "r.idRegistro, e.codigo, e.nombre, e.apellido, "
		     + "r.fechaClase, r.estado, r.materiaTema, "
		     + "d.nombre, d.apellido, e.grado) "
		     + "FROM RegistroAsistencia r "
		     + "JOIN Estudiante e ON r.codigoEstudiante = e.codigo "
		     + "JOIN Docente d ON r.idDocente = d.idDocente")
		List<RegistroVista> listarConJoin();

    //ESTA ES LA QUERY CORRECTA (NO TOCAR)
    @Query("SELECT r FROM RegistroAsistencia r WHERE r.codigoEstudiante = :codigo")
    List<RegistroAsistencia> listarPorCodigoEstudiante(@Param("codigo") String codigo);

}
