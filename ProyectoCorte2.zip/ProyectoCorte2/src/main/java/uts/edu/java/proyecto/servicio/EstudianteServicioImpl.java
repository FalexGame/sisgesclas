package uts.edu.java.proyecto.servicio;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uts.edu.java.proyecto.modelo.Estudiante;
import uts.edu.java.proyecto.repositorio.EstudianteRepositorio;

@Service
public class EstudianteServicioImpl implements EstudianteServicio {

    @Autowired
    private EstudianteRepositorio repositorio;

    @Override
    public List<Estudiante> listar() {
        return repositorio.findAll();
    }

    @Override
    public Estudiante obtenerPorCodigo(String codigo) {
        return repositorio.findById(codigo).orElse(null);
    }

    @Override
    public Estudiante buscarPorDocumento(String documento) {
        return repositorio.findByDocumento(documento);
    }

    @Override
    public void guardar(Estudiante estudiante) {
        repositorio.save(estudiante);
    }

    @Override
    public void eliminar(String codigo) {
        repositorio.deleteById(codigo);
    }
}
