package uts.edu.java.proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoCorte2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoCorte2Application.class, args);
	}

}
