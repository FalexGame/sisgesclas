package uts.edu.java.proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCorte2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
